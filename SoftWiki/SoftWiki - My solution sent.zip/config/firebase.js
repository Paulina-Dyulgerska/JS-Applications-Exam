const firebaseConfig = {
  apiKey: "AIzaSyBjZEVcDhciq5mek67vgv4cLC-0jIFspwg",
  authDomain: "jsadvancedexam.firebaseapp.com",
  databaseURL: "https://jsadvancedexam.firebaseio.com",
  projectId: "jsadvancedexam",
  storageBucket: "jsadvancedexam.appspot.com",
  messagingSenderId: "963413294878",
  appId: "1:963413294878:web:4eec81de10f6f15196930f"
};

firebase.initializeApp(firebaseConfig);