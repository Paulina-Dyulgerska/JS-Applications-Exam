import user from './user.js';
import item from './item.js';
import home from './home.js';

export default {
    user,
    item,
    home,
}