This app is depending on the following node modules:
    - handlebars,
    - jquery,
    - sammy.
Just type in terminal "npm install" to install them quickly.

This application is using a firebase cloud firestore database. 
Configurations are stored in file: config/firebase.js.